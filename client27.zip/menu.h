#pragma once
#include "client.h"
#include <iostream>
#include <string>
#include <limits>

void ShowAllMessages();
std::string SendMessage();
void ShowUserMenu();
std::string ShowLoginMenu();
std::string ShowRegisterMenu();
void ShowMainMenu();