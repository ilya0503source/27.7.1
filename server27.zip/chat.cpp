﻿#include "chat.h"

extern Logger logger;

void Chat::saveDataToFile() {
    saveUsersToFile();
    saveMessagesToFile();
}

void Chat::loadUsersFromFile() {
    _users.clear();

    std::string query = "SELECT login, password, name FROM users";
    if (mysql_query(mysql, query.c_str())) {
        logger.asyncLogAndRead("Query failed");
        return;
    }

    MYSQL_RES* res = mysql_store_result(mysql);
    if (!res) return;

    while (MYSQL_ROW row = mysql_fetch_row(res)) {
        std::string login = row[0];
        std::string password = row[1];
        std::string name = row[2];

        _users[login] = std::make_shared<User>(login, password, name);
    }

    mysql_free_result(res);
}

void Chat::saveUsersToFile() {
    for (const auto& user : _users) {
        std::string login = user.first;
        std::string password = user.second->getPassword();
        std::string name = user.second->getName();

        char* escapedLogin = new char[login.length() * 2 + 1];
        char* escapedPassword = new char[password.length() * 2 + 1];
        char* escapedName = new char[name.length() * 2 + 1];

        mysql_real_escape_string(mysql, escapedLogin, login.c_str(), login.length());
        mysql_real_escape_string(mysql, escapedPassword, password.c_str(), password.length());
        mysql_real_escape_string(mysql, escapedName, name.c_str(), name.length());

        std::string query = "INSERT INTO users (login, password, name) VALUES ('" +
            std::string(escapedLogin) + "', '" +
            std::string(escapedPassword) + "', '" +
            std::string(escapedName) + "') "
            "ON DUPLICATE KEY UPDATE password=VALUES(password), name=VALUES(name)";

        if (mysql_query(mysql, query.c_str())) {
            std::cerr << "Insert failed: " << mysql_error(mysql) << std::endl;
            const char* mysqlErr = mysql_error(mysql);
            std::string errMsg(mysqlErr ? mysqlErr : "");
            logger.asyncLogAndRead(errMsg);
        }

        delete[] escapedLogin;
        delete[] escapedPassword;
        delete[] escapedName;
    }
}

void Chat::loadMessagesFromFile() {
    _messages.clear();

    std::string query = "SELECT sender_id, receiver_id, text FROM messages";
    if (mysql_query(mysql, query.c_str())) {
        const char* mysqlErr = mysql_error(mysql);
        std::string errMsg(mysqlErr ? mysqlErr : "");
        logger.asyncLogAndRead(errMsg);
        return;
    }

    MYSQL_RES* res = mysql_store_result(mysql);
    if (!res) return;

    while (MYSQL_ROW row = mysql_fetch_row(res)) {
 
        std::string from = row[0]; 
        std::string to = row[1];
        std::string text = row[2];

        _messages.push_back(std::make_shared<Message>(from, to, text));
    }

    mysql_free_result(res);
}

bool Chat::saveSingleMessage(const std::shared_ptr<Message>& message) {
    std::string from = message->getFrom();
    std::string to = message->getTo();
    std::string text = message->getText();

    char* escapedFrom = new char[from.length() * 2 + 1];
    char* escapedTo = new char[to.length() * 2 + 1];
    char* escapedText = new char[text.length() * 2 + 1];

    mysql_real_escape_string(mysql, escapedFrom, from.c_str(), from.length());
    mysql_real_escape_string(mysql, escapedTo, to.c_str(), to.length());
    mysql_real_escape_string(mysql, escapedText, text.c_str(), text.length());

    std::string query = "INSERT INTO messages (sender_id, receiver_id, text) VALUES ("
        " (SELECT id FROM users WHERE login = '" + std::string(escapedFrom) + "'),"
        " (SELECT id FROM users WHERE login = '" + std::string(escapedTo) + "'),"
        " '" + std::string(escapedText) + "')";

    bool success = (mysql_query(mysql, query.c_str()) == 0);

    delete[] escapedFrom;
    delete[] escapedTo;
    delete[] escapedText;

    return success;
}


void Chat::saveMessagesToFile() {
    for (const auto& message : _messages) {
        std::string from = message->getFrom();
        std::string to = message->getTo();
        std::string text = message->getText();

        char* escapedFrom = new char[from.length() * 2 + 1];
        char* escapedTo = new char[to.length() * 2 + 1];
        char* escapedText = new char[text.length() * 2 + 1];
        mysql_real_escape_string(mysql, escapedFrom, from.c_str(), from.length());
        mysql_real_escape_string(mysql, escapedTo, to.c_str(), to.length());
        mysql_real_escape_string(mysql, escapedText, text.c_str(), text.length());

        std::string checkQuery = "SELECT COUNT(*) FROM messages WHERE "
            "sender_id = (SELECT id FROM users WHERE login = '" + std::string(escapedFrom) + "') AND "
            "receiver_id = (SELECT id FROM users WHERE login = '" + std::string(escapedTo) + "') AND "
            "text = '" + std::string(escapedText) + "'";

        if (mysql_query(mysql, checkQuery.c_str())) {
            const char* mysqlErr = mysql_error(mysql);
            std::string errMsg(mysqlErr ? mysqlErr : "");
            logger.asyncLogAndRead(errMsg);
            delete[] escapedFrom;
            delete[] escapedTo;
            delete[] escapedText;
            continue;
        }

        MYSQL_RES* res = mysql_store_result(mysql);
        bool exists = false;
        if (res) {
            MYSQL_ROW row = mysql_fetch_row(res);
            exists = (atoi(row[0]) > 0);
            mysql_free_result(res);
        }

        if (exists) {
            delete[] escapedFrom;
            delete[] escapedTo;
            delete[] escapedText;
            continue;
        }

        std::string insertQuery = "INSERT INTO messages (sender_id, receiver_id, text) VALUES ("
            " (SELECT id FROM users WHERE login = '" + std::string(escapedFrom) + "'),"
            " (SELECT id FROM users WHERE login = '" + std::string(escapedTo) + "'),"
            " '" + std::string(escapedText) + "')";

        if (mysql_query(mysql, insertQuery.c_str())) {
            const char* mysqlErr = mysql_error(mysql);
            std::string errMsg(mysqlErr ? mysqlErr : "");
            logger.asyncLogAndRead(errMsg);
        }

        delete[] escapedFrom;
        delete[] escapedTo;
        delete[] escapedText;
    }
}

void Chat::start() {
    _chatRunning = true;
}

std::shared_ptr<User> Chat::getUserByLogin(const std::string& login) const {
    auto it = _users.find(login);
    if (it != _users.end()) {
        return it->second;
    }
    return nullptr;
}

std::shared_ptr<User> Chat::getUserByName(const std::string& name) const {
    for (const auto& user : _users) {
        if (user.second->getName() == name) {
            return user.second;
        }
    }
    return nullptr;
}

char* Chat::signUp(const std::string& login, const std::string& password, const std::string& name) {

    if (getUserByLogin(login)) {
        logger.asyncLogAndRead("The login already exists!");
        return _strdup("The login already exists!");
    }

    if (name == "all") {
        logger.asyncLogAndRead("The name cannot be all!");
        return _strdup("The name cannot be all!");
    }

    auto newUser = std::make_shared<User>(login, password, name);
    _users[login] = newUser;
    _currentUser = newUser;
    logger.asyncLogAndRead(login + " successfully registered!");
    saveUsersToFile();
    return _strdup("You have successfully registered!");
}

char* Chat::Flogin(const std::string& login, const std::string& password) {
    loadUsersFromFile();
    _currentUser = getUserByLogin(login);

    if (_currentUser == nullptr || (password != _currentUser->getPassword())) {
        _currentUser = nullptr;
        logger.asyncLogAndRead("Incorrect login or password!");
        return _strdup("Incorrect login or password!");
    }
    logger.asyncLogAndRead("Authorization is successful!");
    return _strdup("Authorization is successful!");
}

char* Chat::sendMessage(const std::string& to, const std::string& text) {
    std::shared_ptr<User> recipient = nullptr;


    if (!(to == "all" || (recipient = getUserByName(to)))) {
        logger.asyncLogAndRead("The user with the name " + to + " does not exist");
        return _strdup("name error!");
    }

    auto newMessage = std::make_shared<Message>(
        _currentUser->getName(),
        (to == "all") ? "all" : recipient->getName(),
        text
    );

    _messages.push_back(newMessage);

    if (saveSingleMessage(newMessage)) {
        logger.asyncLogAndRead("Message delivered!");
        return _strdup("Message delivered!");
    }
    else {
        logger.asyncLogAndRead("Failed to save message!");
        return _strdup("Failed to save message!");
    }
}

char* Chat::showAllUsersName() {
    loadUsersFromFile();
    std::stringstream message;
    message << "showusers;";

    bool isFirst = true;

    for (const auto& user : _users) {
        if (!isFirst) {
            message << "; ";
        }

        std::string name = user.second->getName();

        if (_currentUser && _currentUser->getLogin() == user.second->getLogin()) {
            name += " (You)";
        }

        message << name;
        isFirst = false;
    }

    std::string result = message.str();
    return _strdup(result.c_str());
}




char* Chat::showChat() {
    std::stringstream message;
    loadMessagesFromFile();

    message << "showchat;";

    bool isFirst = true;

    for (const auto& chatMessage : _messages) {
        int senderId = std::stoi(chatMessage->getFrom());
        int receiverId = std::stoi(chatMessage->getTo());

        std::string fromName = getUserNameById(senderId);
        std::string toName = (receiverId == -1) ? "all" : getUserNameById(receiverId);

        std::string fromDisplay;
        std::string toDisplay;

        if (_currentUser && _currentUser->getName() == fromName) {
            fromDisplay = "You";
        }
        else {
            fromDisplay = fromName;
        }

        if (receiverId == -1) {
            toDisplay = "All";
        }
        else if (_currentUser && _currentUser->getName() == toName) {
            toDisplay = "You";
        }
        else {
            toDisplay = toName;
        }

        if (_currentUser) {
            bool isSender = (_currentUser->getName() == fromName);
            bool isReceiver = (_currentUser->getName() == toName);
            bool isForAll = (receiverId == -1);

            if (!(isSender || isReceiver || isForAll)) {
                continue;
            }
        }

        std::string msg = fromDisplay + " -> " + toDisplay + ": " + chatMessage->getText();

        if (!isFirst) {
            message << "; ";
        }
        message << msg;
        isFirst = false;
    }

    std::string result = message.str();
    return _strdup(result.c_str());
}

std::string Chat::getUserNameById(int id) {
    std::string query = "SELECT name FROM users WHERE id = " + std::to_string(id);
    if (mysql_query(mysql, query.c_str())) {
        const char* mysqlErr = mysql_error(mysql);
        std::string errMsg(mysqlErr ? mysqlErr : "");
        logger.asyncLogAndRead(errMsg);
        return "";
    }

    MYSQL_RES* res = mysql_store_result(mysql);
    if (!res) return "";

    if (MYSQL_ROW row = mysql_fetch_row(res)) {
        mysql_free_result(res);
        return row[0];
    }

    mysql_free_result(res);
    return "";
}